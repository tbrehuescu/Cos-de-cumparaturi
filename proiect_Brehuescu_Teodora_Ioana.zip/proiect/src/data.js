"use strict";

const data = {
    items: [
        {
            name: "Supa",
            price: 10.45,
            image: "img/supa.jpg"
        },
        {
            name: "Friptura",
            price: 11.35,
            image: "img/friptura.jpg"
        },

        {
            name: "Somon",
            price: 45.85,
            image: "img/somon.jpg"
        },
        {
            name: "Prajtura cu banane",
            price: 12.85,
            image: "img/banane.jpg"
        },
        {
            name: "Briosa",
            price: 9.55,
            image: "img/briosa.jpg"
        },
        {
            name: "Tort de fructe",
            price: 32.55,
            image: "img/tort.jpg"
        }                
    ]
};
